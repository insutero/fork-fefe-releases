#define NO_UINT32_MACROS
#include <libowfat/uint32.h>

void uint32_pack(char out[4],uint32 in) {
  *out=(char)in; in>>=8;
  *++out=(char)in; in>>=8;
  *++out=(char)in; in>>=8;
  *++out=(char)in;
}
